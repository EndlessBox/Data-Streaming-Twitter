See Homebrew's [releases on GitHub](https://github.com/Homebrew/brew/releases) for the changelog.
