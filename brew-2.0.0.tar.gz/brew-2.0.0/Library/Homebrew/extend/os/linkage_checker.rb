require "extend/os/linux/linkage_checker" if OS.linux?
