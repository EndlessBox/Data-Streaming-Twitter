require "extend/os/mac/language/java" if OS.mac?
