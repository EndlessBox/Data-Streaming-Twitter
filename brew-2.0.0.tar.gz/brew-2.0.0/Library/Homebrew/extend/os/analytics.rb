require "extend/os/mac/utils/analytics" if OS.mac?
