require "cask/artifact/moved"

module Cask
  module Artifact
    class Colorpicker < Moved
    end
  end
end
