require "cask/artifact/moved"

module Cask
  module Artifact
    class InputMethod < Moved
    end
  end
end
