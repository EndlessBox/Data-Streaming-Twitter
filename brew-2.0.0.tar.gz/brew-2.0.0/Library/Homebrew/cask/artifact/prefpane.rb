require "cask/artifact/moved"

module Cask
  module Artifact
    class Prefpane < Moved
      def self.english_name
        "Preference Pane"
      end
    end
  end
end
