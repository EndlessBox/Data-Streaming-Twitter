require "cask/artifact/moved"

module Cask
  module Artifact
    class AudioUnitPlugin < Moved
    end
  end
end
