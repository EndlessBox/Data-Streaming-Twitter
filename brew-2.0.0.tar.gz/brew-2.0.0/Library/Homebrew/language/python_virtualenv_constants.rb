PYTHON_VIRTUALENV_URL =
  "https://files.pythonhosted.org/packages/8b/f4" \
  "/360aa656ddb0f4168aeaa1057d8784b95d1ce12f34332c1cf52420b6db4e" \
  "/virtualenv-16.3.0.tar.gz".freeze
PYTHON_VIRTUALENV_SHA256 =
  "729f0bcab430e4ef137646805b5b1d8efbb43fe53d4a0f33328624a84a5121f7".freeze
